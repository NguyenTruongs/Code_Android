
-- --------------------------------------------------------

--
-- Table structure for table `users_table`
--

CREATE TABLE `users_table` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users_table`
--

INSERT INTO `users_table` (`id`, `name`, `email`, `password`) VALUES
(1, 'b', 'b', '$2y$10$.9NtIYOyqIgrwBptnOgLmOAAgHRH/hKnQxF4ousZRr72rO0dpeNji'),
(3, 'a', 'a', '$2y$10$lindMHqx59wgTotPrXwsrO/2/6zBowYjvn0KxC5l181beEtIiLBQm');
